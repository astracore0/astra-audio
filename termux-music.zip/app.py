import os, re, json, glob
from flask import Flask, send_from_directory, request, jsonify, Response
import yt_dlp

app = Flask(__name__, static_folder=".")
MUSIC_DIR = os.path.expanduser("~/storage/shared/Download/Music")
META_FILE = os.path.join(MUSIC_DIR, ".astra_meta.json")
os.makedirs(MUSIC_DIR, exist_ok=True)

def get_meta():
    if os.path.exists(META_FILE):
        try:
            with open(META_FILE, 'r') as f: return json.load(f)
        except: return {}
    return {}

def save_meta(d):
    try:
        with open(META_FILE, 'w') as f: json.dump(d, f)
    except: pass

@app.route('/')
def index(): return send_from_directory('.', 'index.html')

@app.route('/<path:p>')
def static_proxy(p): return send_from_directory('.', p)

@app.route('/stream/<path:filename>')
def stream(filename):
    path = os.path.join(MUSIC_DIR, filename)
    if not os.path.exists(path): return "Not Found", 404
    size = os.path.getsize(path)
    rng = request.headers.get('Range')
    if not rng:
        with open(path, 'rb') as f: return Response(f.read(), mimetype='audio/mpeg')
    m = re.search(r'(\d+)-(\d*)', rng)
    b1 = int(m.group(1)) if m else 0
    b2 = int(m.group(2)) if (m and m.group(2)) else min(b1 + 262144 - 1, size - 1)
    length = b2 - b1 + 1
    with open(path, 'rb') as f:
        f.seek(b1)
        data = f.read(length)
    rv = Response(data, 206, mimetype='audio/mpeg', direct_passthrough=True)
    rv.headers.add('Content-Range', f'bytes {b1}-{b2}/{size}')
    rv.headers.add('Accept-Ranges', 'bytes')
    rv.headers.add('Content-Length', str(length))
    return rv

@app.route('/api/library')
def library():
    meta = get_meta()
    files = glob.glob(os.path.join(MUSIC_DIR, "*.mp3"))
    files.sort(key=lambda x: os.path.getmtime(x), reverse=True)
    res = []
    for f in files:
        b = os.path.basename(f)
        info = meta.get(b, {})
        vid = info.get('id', '')
        res.append({
            'filename': b,
            'id': vid,
            'title': info.get('title', os.path.splitext(b)[0]),
            'uploader': info.get('uploader', 'Local Track'),
            'low_thumb': f"https://i.ytimg.com/vi/{vid}/mqdefault.jpg" if vid else "",
            'high_thumb': f"https://i.ytimg.com/vi/{vid}/hqdefault.jpg" if vid else ""
        })
    return jsonify(res)

@app.route('/api/search', methods=['POST'])
def search():
    q = request.json.get('query', '').strip()
    opts = {'default_search': 'ytsearch6', 'quiet': True, 'skip_download': True, 'extract_flat': True}
    out = []
    with yt_dlp.YoutubeDL(opts) as ydl:
        try:
            info = ydl.extract_info(q, download=False)
            for e in info.get('entries', []):
                vid = e.get('id')
                if not vid: continue
                out.append({
                    'id': vid,
                    'title': e.get('title', 'Unknown Track'),
                    'uploader': e.get('uploader', 'Artist'),
                    'low_thumb': f"https://i.ytimg.com/vi/{vid}/mqdefault.jpg",
                    'high_thumb': f"https://i.ytimg.com/vi/{vid}/hqdefault.jpg"
                })
        except Exception as ex:
            return jsonify({'error': str(ex)}), 500
    return jsonify({'results': out})

def clean_old_cache(limit, pinned):
    if limit <= 0: return
    files = glob.glob(os.path.join(MUSIC_DIR, "*.mp3"))
    files.sort(key=lambda x: os.path.getmtime(x))
    rem = [f for f in files if os.path.basename(f) not in pinned]
    while len(files) >= limit and rem:
        old = rem.pop(0)
        try:
            os.remove(old)
            files.remove(old)
        except: pass

@app.route('/api/acquire', methods=['POST'])
def acquire():
    d = request.json or {}
    vid = d.get('id')
    title = d.get('title', 'Track')
    uploader = d.get('uploader', 'Artist')
    qual = d.get('quality', '64')
    limit = int(d.get('cacheLimit', 5))
    pinned = d.get('pinned', [])
    if not vid: return jsonify({'status': 'error', 'msg': 'Invalid video ID'}), 400

    safe = re.sub(r'[/\\:*?"<>|]', '_', title).strip()[:80]
    fname = f"{safe}.mp3"
    fpath = os.path.join(MUSIC_DIR, fname)

    if not os.path.exists(fpath):
        clean_old_cache(limit, pinned)
        url = f"https://www.youtube.com/watch?v={vid}"
        opts = {
            'format': 'worstaudio/bestaudio',
            'outtmpl': os.path.join(MUSIC_DIR, f"{safe}.%(ext)s"),
            'quiet': True,
            'socket_timeout': 30,
            'retries': 5,
            'postprocessors': [{'key': 'FFmpegExtractAudio', 'preferredcodec': 'mp3', 'preferredquality': qual}],
        }
        try:
            with yt_dlp.YoutubeDL(opts) as ydl:
                ydl.download([url])
        except Exception as e:
            return jsonify({'status': 'error', 'msg': 'Network timeout on 128kbps link. Try 64kbps in Settings.'}), 500

    meta = get_meta()
    meta[fname] = {'id': vid, 'title': title, 'uploader': uploader}
    save_meta(meta)
    return jsonify({
        'status': 'ok',
        'filename': fname,
        'id': vid,
        'title': title,
        'uploader': uploader,
        'low_thumb': f"https://i.ytimg.com/vi/{vid}/mqdefault.jpg",
        'high_thumb': f"https://i.ytimg.com/vi/{vid}/hqdefault.jpg"
    })

@app.route('/api/delete', methods=['POST'])
def delete():
    f = request.json.get('filename')
    if f:
        p = os.path.join(MUSIC_DIR, f)
        if os.path.exists(p):
            try: os.remove(p)
            except: pass
    return jsonify({'status': 'ok'})

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5000, threaded=True)
