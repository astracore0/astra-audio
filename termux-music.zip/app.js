let library = [];
let queue = [];
let currentIndex = -1;
let playedIds = JSON.parse(localStorage.getItem('astra_played') || '[]');
let pinnedFiles = JSON.parse(localStorage.getItem('astra_pinned') || '[]');
let prefs = JSON.parse(localStorage.getItem('astra_prefs') || '{"quality":"64","limit":5,"autoDel":false}');

const audio = document.getElementById('audioEl');
const statusLine = document.getElementById('statusLine');
const playSvg = document.getElementById('playSvg');
const dockSpinner = document.getElementById('dockSpinner');

// Web Audio API Equalizer Nodes
let audioCtx, bassNode, midNode, trebleNode;

function initAudioEngine() {
    if (audioCtx) return;
    try {
        const AudioContext = window.AudioContext || window.webkitAudioContext;
        audioCtx = new AudioContext();
        const src = audioCtx.createMediaElementSource(audio);

        bassNode = audioCtx.createBiquadFilter();
        bassNode.type = 'lowshelf';
        bassNode.frequency.value = 60;

        midNode = audioCtx.createBiquadFilter();
        midNode.type = 'peaking';
        midNode.frequency.value = 1000;

        trebleNode = audioCtx.createBiquadFilter();
        trebleNode.type = 'highshelf';
        trebleNode.frequency.value = 12000;

        src.connect(bassNode);
        bassNode.connect(midNode);
        midNode.connect(trebleNode);
        trebleNode.connect(audioCtx.destination);
    } catch (e) { console.log("EQ init skipped"); }
}

function updateEQ() {
    initAudioEngine();
    const b = parseInt(document.getElementById('bassSlider').value);
    const m = parseInt(document.getElementById('midSlider').value);
    const t = parseInt(document.getElementById('trebleSlider').value);

    document.getElementById('bassVal').innerText = `${b} dB`;
    document.getElementById('midVal').innerText = `${m} dB`;
    document.getElementById('trebleVal').innerText = `${t} dB`;

    if (bassNode) bassNode.gain.value = b;
    if (midNode) midNode.gain.value = m;
    if (trebleNode) trebleNode.gain.value = t;

    const warn = document.getElementById('bassWarning');
    warn.style.display = (b >= 18) ? 'block' : 'none';
}

function toggleDrawer(open) {
    document.getElementById('drawerBackdrop').classList.toggle('open', open);
    document.getElementById('navDrawer').classList.toggle('open', open);
}

function navTo(view, btn) {
    document.querySelectorAll('.page-section').forEach(s => s.style.display = 'none');
    document.getElementById(`view-${view}`).style.display = 'block';
    document.querySelectorAll('.nav-item').forEach(b => b.classList.remove('active'));
    if (btn) btn.classList.add('active');
    toggleDrawer(false);

    if (view === 'trending') loadTrendingRegion();
    if (view === 'library') refreshLibrary();
    if (view === 'queue') renderQueue();
}

function setStatus(msg) { statusLine.innerText = msg; }

// Render Cards with Low-Res Thumbnail & Buffer Spinner on Click
function createTrackCard(item, container, isLocal = false) {
    const div = document.createElement('div');
    div.className = 'track-item';
    const thumb = item.low_thumb || "data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' width='48' height='48'><rect width='48' height='48' fill='%23222'/></svg>";

    div.innerHTML = `
        <img class="track-thumb" src="${thumb}" loading="lazy" alt="Thumb">
        <div class="track-info">
            <div class="t-title">${item.title}</div>
            <div class="t-sub">${item.uploader || 'Artist'}</div>
        </div>
        <button class="listen-btn">
            <span class="btn-text">${isLocal ? 'Play' : 'Listen'}</span>
            <div class="btn-spinner" style="display:none;"></div>
        </button>
    `;

    const btn = div.querySelector('.listen-btn');
    btn.onclick = (e) => {
        e.stopPropagation();
        if (isLocal) {
            playLocalTrack(item);
        } else {
            acquireAndStream(item, btn);
        }
    };
    container.appendChild(div);
}

// Acquire Song with Button Spinner & High-Res Upgrade on Play
async function acquireAndStream(item, btnEl) {
    const txt = btnEl ? btnEl.querySelector('.btn-text') : null;
    const spin = btnEl ? btnEl.querySelector('.btn-spinner') : null;
    if (btnEl) { btnEl.disabled = true; txt.style.display = 'none'; spin.style.display = 'block'; }
    dockSpinner.style.display = 'block';
    playSvg.style.display = 'none';

    setStatus(`Negotiating 64kbps fast-stream for "${item.title.slice(0, 28)}..."`);

    try {
        const res = await fetch('/api/acquire', {
            method: 'POST',
            headers: {'Content-Type': 'application/json'},
            body: JSON.stringify({
                id: item.id,
                title: item.title,
                uploader: item.uploader,
                quality: prefs.quality,
                cacheLimit: prefs.limit,
                pinned: pinnedFiles
            })
        });
        const data = await res.json();
        if (data.status === 'ok') {
            if (!playedIds.includes(item.id)) {
                playedIds.push(item.id);
                localStorage.setItem('astra_played', JSON.stringify(playedIds));
            }
            await refreshLibrary();
            playLocalTrack(data);
            setStatus(`Streaming "${data.title}" — High-Res Art Loaded.`);
        } else {
            setStatus(`Stream error: ${data.msg}`);
        }
    } catch (err) {
        setStatus("Connection timed out on slow link. Retry in a moment.");
    } finally {
        if (btnEl) { btnEl.disabled = false; txt.style.display = 'inline'; spin.style.display = 'none'; }
        dockSpinner.style.display = 'none';
        playSvg.style.display = 'block';
    }
}

function playLocalTrack(track) {
    initAudioEngine();
    if (audioCtx && audioCtx.state === 'suspended') audioCtx.resume();

    // Load High-Quality Photo in Dock
    const hiRes = track.high_thumb || track.low_thumb || "data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' width='60' height='60'><rect width='60' height='60' fill='%231f242d'/></svg>";
    document.getElementById('dockArt').src = hiRes;
    document.getElementById('dockTitle').innerText = track.title;
    document.getElementById('dockArtist').innerText = track.uploader || 'Astra Cache';

    const idx = library.findIndex(x => x.filename === track.filename);
    currentIndex = idx !== -1 ? idx : 0;
    queue = library.slice();

    const pinBtn = document.getElementById('pinBtn');
    const isPinned = pinnedFiles.includes(track.filename);
    pinBtn.classList.toggle('active', isPinned);
    pinBtn.innerText = isPinned ? 'Saved' : 'Keep';

    audio.src = `/stream/${encodeURIComponent(track.filename)}`;
    audio.play().then(() => {
        setPlayIcon(true);
    }).catch(() => setStatus("Tap Play button to start audio output."));
}

function setPlayIcon(playing) {
    playSvg.innerHTML = playing
        ? '<path fill="currentColor" d="M6 19h4V5H6v14zm8-14v14h4V5h-4z"/>'
        : '<path fill="currentColor" d="M8 5v14l11-7z"/>';
}

function togglePlay() {
    if (!audio.src) return;
    initAudioEngine();
    if (audio.paused) { audio.play(); setPlayIcon(true); }
    else { audio.pause(); setPlayIcon(false); }
}

function nextSong() {
    if (library.length === 0) return;
    currentIndex = (currentIndex + 1) % library.length;
    playLocalTrack(library[currentIndex]);
}

function prevSong() {
    if (library.length === 0) return;
    currentIndex = (currentIndex - 1 + library.length) % library.length;
    playLocalTrack(library[currentIndex]);
}

audio.onended = async () => {
    const finished = library[currentIndex];
    if (prefs.autoDel && finished && !pinnedFiles.includes(finished.filename)) {
        await fetch('/api/delete', {
            method: 'POST',
            headers: {'Content-Type': 'application/json'},
            body: JSON.stringify({ filename: finished.filename })
        });
        await refreshLibrary();
    }
    nextSong();
};

// Discovery: Global English Unheard Songs
async function loadDiscovery() {
    const pools = [
        "Billboard Global 200 English Hits",
        "Popular English Indie Pop Hits",
        "Top Global Synthwave & Pop Tracks",
        "UK Top 40 English Singles",
        "Viral Global English Songs"
    ];
    const pick = pools[Math.floor(Math.random() * pools.length)];
    setStatus(`Curating unheard global tracks: ${pick}...`);

    try {
        const res = await fetch('/api/search', {
            method: 'POST',
            headers: {'Content-Type': 'application/json'},
            body: JSON.stringify({ query: pick })
        });
        const data = await res.json();
        const grid = document.getElementById('discoverGrid');
        grid.innerHTML = '';
        const unheard = (data.results || []).filter(x => !playedIds.includes(x.id));
        unheard.forEach(item => createTrackCard(item, grid, false));
        setStatus(`Loaded ${unheard.length} fresh tracks ready to stream.`);
    } catch {
        setStatus("Offline mode: Check Saved Library tab.");
    }
}

async function loadTrendingRegion() {
    const regionQuery = document.getElementById('regionSelect').value;
    setStatus(`Fetching regional charts for ${regionQuery}...`);
    const grid = document.getElementById('trendingGrid');
    grid.innerHTML = '';
    try {
        const res = await fetch('/api/search', {
            method: 'POST',
            headers: {'Content-Type': 'application/json'},
            body: JSON.stringify({ query: regionQuery })
        });
        const data = await res.json();
        (data.results || []).forEach(item => createTrackCard(item, grid, false));
        setStatus(`Chart updated: ${regionQuery}`);
    } catch {
        setStatus("Could not fetch regional chart.");
    }
}

async function runSearch() {
    const q = document.getElementById('searchInput').value.trim();
    if (!q) return;
    setStatus(`Searching global index for "${q}"...`);
    document.getElementById('searchBoxArea').style.display = 'block';
    const grid = document.getElementById('searchGrid');
    grid.innerHTML = '';

    try {
        const res = await fetch('/api/search', {
            method: 'POST',
            headers: {'Content-Type': 'application/json'},
            body: JSON.stringify({ query: q })
        });
        const data = await res.json();
        (data.results || []).forEach(item => createTrackCard(item, grid, false));
        setStatus(`Found ${(data.results || []).length} matches for "${q}".`);
    } catch {
        setStatus("Search request timed out.");
    }
}

async function refreshLibrary() {
    try {
        const res = await fetch('/api/library');
        library = await res.json();
        document.getElementById('libCounter').innerText = `${library.length} stored`;
        const grid = document.getElementById('libraryGrid');
        grid.innerHTML = '';
        library.forEach(item => createTrackCard(item, grid, true));
    } catch {}
}

function renderQueue() {
    const grid = document.getElementById('queueGrid');
    grid.innerHTML = '';
    library.forEach(item => createTrackCard(item, grid, true));
}

function togglePin() {
    if (currentIndex < 0 || !library[currentIndex]) return;
    const fname = library[currentIndex].filename;
    const i = pinnedFiles.indexOf(fname);
    if (i === -1) pinnedFiles.push(fname);
    else pinnedFiles.splice(i, 1);
    localStorage.setItem('astra_pinned', JSON.stringify(pinnedFiles));
    const pinBtn = document.getElementById('pinBtn');
    pinBtn.classList.toggle('active', i === -1);
    pinBtn.innerText = (i === -1) ? 'Saved' : 'Keep';
}

function savePrefs() {
    prefs.quality = document.getElementById('setQuality').value;
    prefs.limit = parseInt(document.getElementById('setLimit').value);
    prefs.autoDel = document.getElementById('setAutoDel').checked;
    localStorage.setItem('astra_prefs', JSON.stringify(prefs));
    setStatus("Preferences saved to local profile.");
}

// Seek & Volume Sliders
const seekBar = document.getElementById('seekBar');
seekBar.oninput = () => { audio.currentTime = seekBar.value; };
document.getElementById('volBar').oninput = (e) => { audio.volume = e.target.value; };

audio.ontimeupdate = () => {
    seekBar.max = Math.floor(audio.duration) || 0;
    seekBar.value = Math.floor(audio.currentTime) || 0;
    document.getElementById('timeCur').innerText = fmt(audio.currentTime);
    document.getElementById('timeTot').innerText = fmt(audio.duration);
};

function fmt(s) {
    if (!s || isNaN(s)) return "0:00";
    const m = Math.floor(s / 60), sec = Math.floor(s % 60);
    return `${m}:${sec < 10 ? '0' : ''}${sec}`;
}

window.onload = () => {
    document.getElementById('setQuality').value = prefs.quality;
    document.getElementById('setLimit').value = prefs.limit;
    document.getElementById('setAutoDel').checked = prefs.autoDel;
    refreshLibrary();
    loadDiscovery();
};
